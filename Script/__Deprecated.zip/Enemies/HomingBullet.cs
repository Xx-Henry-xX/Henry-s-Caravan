using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using SoftFloat;
using SFAABBCC_Prereqs;
using static SFAABBCC_Prereqs.CC;

public class HomingBullet : Bullet
{
    int duration = -1;
    sfloat maxTurn = (sfloat)5;
    sfloat spd = (sfloat)0.5;
    sfloat currentAngle = (sfloat)0;

    public void HomingSetup()
    {

    }

    void Movement()
    {
        position += velocity;
    }
}
