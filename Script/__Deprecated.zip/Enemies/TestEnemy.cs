using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using SoftFloat;
using SFAABBCC_Prereqs;
using EnemyPrereqs;
using static SFAABBCC_Prereqs.CC;

public class TestEnemy : Enemy_Base
{
    int counter = 0;
    // Start is called before the first frame update
    void Awake()
    {
        PossiblyConstantStuffSetup();
        hitboxGroup = new SFAABB[] { new SFAABB(new SFPoint((sfloat)0, (sfloat)0), new SFPoint((sfloat)0.5f, (sfloat)0.5f)) };
        Random.InitState(gManager.p1Score + gManager.rank);
        position = new SFPoint((sfloat)Random.Range(-7.0f, 7.0f), (sfloat)11);
        movement = new SFPoint((sfloat)0, (sfloat)(-0.125));
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        position += movement;
        if (position.y < (sfloat)(-11)) Destroy(gameObject);
        transform.SetPositionAndRotation(new Vector3((float)position.x, (float)position.y, 0), transform.rotation);

        counter++;
        counter %= 30;
        if (counter == 0 && IntersectBoxVSPoint(bufferArea, position))
        {
            SFPoint bulletVel = gManager.player.GetComponent<PlayerController>().GetHitBox().center - position;
            bulletVel.normalize();
            bulletVel *= (sfloat)0.125;
            GameObject bullet = Instantiate(bulletPrefab, new Vector3(15.0f, 15.0f, 0), Quaternion.Euler(0, 0, 0));
            bullet.GetComponent<Bullet>().Setup((int) BltColor.Purple, (int) BltShape.Bean, position, bulletVel);
        }

        DamageCheck();
    }
}
