using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using SoftFloat;
using SFAABBCC_Prereqs;
using static SFAABBCC_Prereqs.CC;

namespace EnemyPrereqs
{
    public abstract class Enemy_Base : MonoBehaviour
    {
        [Tooltip("Group of hitbox for shot collision\nCenter of each box is used as offset from center")]
        public SFAABB[] hitboxGroup;
        [Tooltip("Position of enemy")]
        public SFPoint position;
        [Tooltip("Movement of enemy in SFPoint")]
        public SFPoint movement;
        [Tooltip("HP value of enemy")]
        public int hp;
        [Tooltip("Base point value of enemy")]
        public int baseValue;
        [Tooltip("Offset from position.y to use for multiplier decision\nfloat ver. for setting in editor")]
        public float m_multiplierYAxisOffset;

        [Tooltip("Offset from position.y to use for multiplier decision\nsfloat ver. for use in code")]
        protected sfloat multiplierYAxisOffset;
        [Tooltip("GameManager object")]
        protected GameManager gManager;
        protected SFAABB bufferArea = new SFAABB(new SFPoint((sfloat)0, (sfloat)0), new SFPoint((sfloat)7, (sfloat)9));
        protected GameObject bulletPrefab;

        public enum BltColor
        {
            Yellow = 0,
            Blue,
            Red,
            Purple,
            Pink,
            Magenta
        }
        public enum BltShape
        {
            Bean = 0,
            Counter8px,
            Counter12px,
            Counter16px,
            DoubleBeam,
            LargeRugby,
            Missile,
            Needle,
            Pulse,
            Ring,
            SingleBeam,
            Spark,
            Strobe6px,
            Strobe8px,
            Strobe16px,
            TJO,
            Whirl
        }

        protected void PossiblyConstantStuffSetup()
        {
            multiplierYAxisOffset = (sfloat)m_multiplierYAxisOffset;
            gManager = FindObjectOfType<GameManager>();
            bulletPrefab = (GameObject)Resources.Load("Prefabs/Bullet", typeof(GameObject));
        }

        protected void DamageCheck()
        {
            bool damagable = IntersectBoxVSPoint(bufferArea, position);

            List<GameObject> alreadyChecked = new List<GameObject>();
            foreach (SFAABB nmeBox in hitboxGroup)
            {
                foreach (GameObject child in GameObject.FindGameObjectsWithTag("PlayerShots"))
                {
                    if (!alreadyChecked.Contains(child) && IntersectBoxVSBox(nmeBox.offset(position), child.GetComponent<PlayerShot>().GetHitBox()))
                    {
                        alreadyChecked.Add(child);
                    }
                }

                foreach (GameObject child in GameObject.FindGameObjectsWithTag("PlayerDeathShots"))
                {
                    if (!alreadyChecked.Contains(child) && IntersectCircleVSBox(child.GetComponent<PlayerDeathShot>().GetHitBox(), nmeBox.offset(position)))
                    {
                        alreadyChecked.Add(child);
                    }
                }
                foreach (GameObject child in GameObject.FindGameObjectsWithTag("PlayerBomber"))
                {
                    if (!alreadyChecked.Contains(child) && IntersectCircleVSBox(child.GetComponent<Bomb>().GetHitBox(), nmeBox.offset(position)))
                    {
                        alreadyChecked.Add(child);
                    }
                }
            }
            foreach (GameObject child in alreadyChecked)
            {
                if (child.tag == "PlayerShots")
                {
                    Destroy(child);
                    if (damagable) hp -= child.GetComponent<PlayerShot>().damage;
                    gManager.p1Score += child.GetComponent<PlayerShot>().damage * 10;
                    if (hp < 1)
                    {
                        gManager.p1Score += 10 * hp;
                        hp = 0;
                    }
                }
                else if (child.tag == "PlayerDeathShots")
                {
                    if (damagable) hp -= child.GetComponent<PlayerDeathShot>().damage;
                    gManager.p1Score += child.GetComponent<PlayerDeathShot>().damage * 20;
                    if (hp < 1)
                    {
                        gManager.p1Score += 20 * hp;
                        hp = 0;
                    }
                }
                else
                {
                    if (damagable) hp -= child.GetComponent<Bomb>().damage;
                    gManager.p1Score += child.GetComponent<Bomb>().damage * 20;
                    if (hp < 1)
                    {
                        gManager.p1Score += 20 * hp;
                        hp = 0;
                    }
                }
            }
            
            if (hp < 1)
            {
                int multi = 10;
                if (!gManager.player.GetComponent<PlayerController>().GetFreeX10())
                {
                    sfloat diff = position.y + multiplierYAxisOffset - GameObject.FindObjectOfType<GameManager>().player.GetComponent<PlayerController>().GetHitBox().center.y;
                    bool brk = false;
                    while (multi > 1 && !brk)
                    {
                        brk = diff < (sfloat)(11 - multi) * (sfloat)1.25f;
                        if (!brk) multi--;
                    }
                }
                gManager.p1Score += baseValue * multi;
                GameObject multifx = Instantiate(Resources.Load<GameObject>("Prefabs/FX"), transform.position, transform.rotation);
                multifx.GetComponent<FXScript>().Setup(0, multi);

                gManager.medalDropCounter -= 10;
                if (multi == 10) gManager.medalDropCounter -= 10;
                if (gManager.medalDropCounter <= 0)
                {
                    multifx = Instantiate(Resources.Load<GameObject>("Prefabs/Item"), transform.position, Quaternion.Euler(0, 0, 0));
                    multifx.GetComponent<ItemScript>().Setup((ItemScript.ItemType)gManager.currentMedal, position);
                    gManager.medalDropCounter += 100;
                }
                Destroy(gameObject);
            }
        }
    }
}
