using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using SoftFloat;
using SFAABBCC_Prereqs;
using static SFAABBCC_Prereqs.CC;

public class Bullet : MonoBehaviour
{
    public sfloat hitboxLength;
    public SFPoint position;
    public SFPoint velocity;
    public HitBoxType hitboxType;
    public BltColor col;
    public BltShape shp;
    //Any Yellow other than Missile becomes YellowRugby

    SpriteRenderer rende;


    public enum HitBoxType
    {
        Circle = 0,
        Line,
        Pulse //2 circles w/ 0.125f radius whose centers are (hitboxLength) away (x axis, one w/ +, the other w/ -) from (position)
    }
    public enum BltColor
    {
        Yellow = 0,
        Blue,
        Red,
        Purple,
        Pink,
        Magenta
    }
    public enum BltShape
    {
        Bean = 0,
        Counter8px,
        Counter12px,
        Counter16px,
        DoubleBeam,
        LargeRugby,
        Missile,
        Needle,
        Pulse,
        Ring,
        SingleBeam,
        Spark,
        Strobe6px,
        Strobe8px,
        Strobe16px,
        TJO,
        Whirl
    }

    readonly string[] bltColorList = { "Yellow", "Blue", "Red", "Purple", "Pink", "Magenta" };
    readonly string[] bltShapeList = { "Bean", "Counter8px", "Counter12px", "Counter16px", "DoubleBeam", "LargeRugby",
        "Missile", "Needle", "Pulse", "Ring", "SingleBeam", "Spark", "Strobe6px", "Strobe8px", "Strobe16px", "TJO", "Whirl" };

    Sprite[] anim = new Sprite[4];
    bool[] animXFlip = { false, false, false, false };
    bool[] animYFlip = { false, false, false, false };
    int frames = 4;
    int currentFrame = 0;
    int delay = 2;

    protected GameManager gManager;

    void Awake()
    {
        rende = gameObject.GetComponent<SpriteRenderer>();
        gManager = FindObjectOfType<GameManager>();
    }

    public void Setup(int m_color, int m_shape, SFPoint m_position, SFPoint m_velocity)
    {
        col = (BltColor) m_color;
        shp = (BltShape) m_shape;
        position = m_position;
        velocity = m_velocity;

        if (col == BltColor.Yellow)
        {
            rende.material = Resources.Load<Material>("Materials/Unshade");
            if (shp == BltShape.Missile)
            {
                anim[0] = gManager.bulletAtlas.GetSprite("YellowMissile");
                frames = 1;
            }
            else
            {
                shp = BltShape.Bean;
                anim[0] = gManager.bulletAtlas.GetSprite("YellowRugby0");
                anim[1] = gManager.bulletAtlas.GetSprite("YellowRugby1");
                anim[2] = gManager.bulletAtlas.GetSprite("YellowRugby2");
                frames = 4;
                delay = 1;
                anim[3] = anim[1];
                animXFlip[3] = true;
            }
        }
        else
        {
            float a = 0f;
            switch (col)
            {
                case BltColor.Red:
                    a = -240f;
                    break; //240 0 270 300 330 --(subtract 240)-> 0 -240 30 60 90 
                case BltColor.Purple:
                    a = 30f;
                    break;
                case BltColor.Magenta:
                    a = 60f;
                    break;
                case BltColor.Pink:
                    a = 90f;
                    break;
            }
            rende.material.SetVector("_HSVAAdjust", new Vector4(a / 360f, 0, 0, 0));
            switch (shp)
            {
                case BltShape.Bean:
                case BltShape.Counter8px:
                case BltShape.Counter12px:
                case BltShape.Counter16px:
                    frames = 4;
                    anim[0] = gManager.bulletAtlas.GetSprite(bltShapeList[(int)shp]);
                    anim[1] = anim[0];
                    anim[2] = anim[0];
                    anim[3] = anim[0];
                    animXFlip[1] = true;
                    animXFlip[2] = true;
                    animYFlip[2] = true;
                    animYFlip[3] = true;
                    break;
                case BltShape.LargeRugby:
                    anim[0] = gManager.bulletAtlas.GetSprite(bltShapeList[(int)shp] + "0");
                    anim[1] = gManager.bulletAtlas.GetSprite(bltShapeList[(int)shp] + "1");
                    anim[2] = gManager.bulletAtlas.GetSprite(bltShapeList[(int)shp] + "2");
                    anim[3] = anim[1];
                    animXFlip[3] = true;
                    break;
                case BltShape.Spark:
                    anim[0] = gManager.bulletAtlas.GetSprite(bltShapeList[(int)shp] + "0");
                    anim[1] = gManager.bulletAtlas.GetSprite("TJO0");
                    anim[2] = gManager.bulletAtlas.GetSprite(bltShapeList[(int)shp] + "2");
                    anim[3] = anim[1];
                    animXFlip[3] = true;
                    break;
                case BltShape.Strobe6px:
                case BltShape.Strobe8px:
                case BltShape.TJO:
                    delay = 3;
                    anim[0] = gManager.bulletAtlas.GetSprite(bltShapeList[(int)shp] + "0");
                    anim[1] = gManager.bulletAtlas.GetSprite(bltShapeList[(int)shp] + "1");
                    anim[2] = anim[0];
                    anim[3] = anim[1];
                    break;
                case BltShape.Strobe16px:
                    frames = 4;
                    delay = 3;
                    anim[0] = gManager.bulletAtlas.GetSprite(bltShapeList[(int)shp] + "0");
                    anim[1] = gManager.bulletAtlas.GetSprite(bltShapeList[(int)shp] + "1");
                    anim[2] = gManager.bulletAtlas.GetSprite(bltShapeList[(int)shp] + "2");
                    anim[3] = anim[1];
                    break;
                case BltShape.Whirl:
                    delay = 4;
                    anim[0] = gManager.bulletAtlas.GetSprite(bltShapeList[(int)shp] + "0");
                    anim[1] = gManager.bulletAtlas.GetSprite(bltShapeList[(int)shp] + "1");
                    anim[2] = anim[0];
                    anim[3] = anim[1];
                    animXFlip[2] = true;
                    animXFlip[3] = true;
                    animYFlip[2] = true;
                    animYFlip[3] = true;
                    break;
                default:
                    frames = gManager.bulletAtlas.GetSprites(anim, bltShapeList[(int)shp]);
                    break;
            }

            switch (shp)
            {
                case BltShape.Bean:
                case BltShape.Strobe6px:
                    hitboxType = HitBoxType.Circle;
                    hitboxLength = (sfloat) 0.125f;
                    break;
                case BltShape.Counter8px:
                case BltShape.Strobe8px:
                    hitboxType = HitBoxType.Circle;
                    hitboxLength = (sfloat) 0.1875f;
                    break;
                case BltShape.Counter12px:
                case BltShape.Spark:
                case BltShape.TJO:
                    hitboxType = HitBoxType.Circle;
                    hitboxLength = (sfloat) 0.25f;
                    break;
                case BltShape.Counter16px:
                case BltShape.DoubleBeam:
                case BltShape.Ring:
                case BltShape.Strobe16px:
                case BltShape.Whirl:
                    hitboxType = HitBoxType.Circle;
                    hitboxLength = (sfloat) 0.375f;
                    break;
                case BltShape.LargeRugby:
                    hitboxType = HitBoxType.Circle;
                    hitboxLength = (sfloat) 0.625f;
                    break;
                case BltShape.Missile:
                    hitboxType = HitBoxType.Line;
                    hitboxLength = (sfloat) 0.75f;
                    break;
                case BltShape.Needle:
                    hitboxType = HitBoxType.Line;
                    hitboxLength = (sfloat) 0.625f;
                    break;
                case BltShape.SingleBeam:
                    hitboxType = HitBoxType.Line;
                    hitboxLength = (sfloat) 1f;
                    break;
                case BltShape.Pulse:
                    hitboxType = HitBoxType.Pulse;
                    hitboxLength = (sfloat) 0.5625f;
                    break;
            }
        }
    }

    void Movement()
    {
        position += velocity;
    }

    void FixedUpdate()
    {
        Movement();
        if (sfloat.Abs(position.y) > (sfloat) 10.5f + hitboxLength || sfloat.Abs(position.x) > (sfloat) 8 + hitboxLength)
        {
            Destroy(gameObject);
        }
        transform.SetPositionAndRotation(new Vector3((float)position.x, (float)position.y, 0), Quaternion.Euler(0, 0, hitboxType == HitBoxType.Line || shp == BltShape.DoubleBeam ? (float)(libm.atan2f(velocity.y, velocity.x) * (sfloat) 180 / sfloat.FromRaw(0x40490fdb)) : 0));
        rende.sprite = anim[currentFrame / delay];
        rende.flipX = animXFlip[currentFrame / delay];
        rende.flipY = animYFlip[currentFrame / delay];
        currentFrame++; 
        currentFrame %= frames * delay;

        bool bonk = false;
        if (col == BltColor.Yellow)
        {
            switch (hitboxType)
            {
                case HitBoxType.Line:
                    SFPoint bltDelta = velocity;
                    bltDelta.normalize();
                    bltDelta *= hitboxLength;
                    foreach (GameObject child in GameObject.FindGameObjectsWithTag("PlayerShots"))
                    {
                        if (IntersectBoxVSSegment(child.GetComponent<PlayerShot>().GetHitBox(), position, bltDelta))
                        {
                            bonk = true;
                            Destroy(child);
                        }
                    }
                    break;
                default:
                    foreach (GameObject child in GameObject.FindGameObjectsWithTag("PlayerShots"))
                    {
                        if (IntersectCircleVSBox(new SFCircle(position, hitboxLength), child.GetComponent<PlayerShot>().GetHitBox()))
                        {
                            bonk = true;
                            Destroy(child);
                        }
                    }
                    break;
            }
        }
        switch (hitboxType)
        {
            case HitBoxType.Circle:
                foreach (GameObject child in GameObject.FindGameObjectsWithTag("PlayerDeathShots"))
                {
                    if (IntersectCircleVSCircle(new SFCircle(position, hitboxLength), child.GetComponent<PlayerDeathShot>().GetHitBox()))
                    {
                        bonk = true;
                        break;
                    }
                }
                foreach (GameObject child in GameObject.FindGameObjectsWithTag("PlayerBomber"))
                {
                    if (IntersectCircleVSCircle(new SFCircle(position, hitboxLength), child.GetComponent<Bomb>().GetHitBox()))
                    {
                        bonk = true;
                        break;
                    }
                }
                break;
            case HitBoxType.Line:
                SFPoint bltDelta = velocity;
                bltDelta.normalize();
                bltDelta *= hitboxLength;
                foreach (GameObject child in GameObject.FindGameObjectsWithTag("PlayerDeathShots"))
                {
                    if (IntersectCircleVSSegment(child.GetComponent<PlayerDeathShot>().GetHitBox(), position, bltDelta))
                    {
                        bonk = true;
                        break;
                    }
                }
                foreach (GameObject child in GameObject.FindGameObjectsWithTag("PlayerBomber"))
                {
                    if (IntersectCircleVSSegment(child.GetComponent<Bomb>().GetHitBox(), position, bltDelta))
                    {
                        bonk = true;
                        break;
                    }
                }
                break;
            case HitBoxType.Pulse:
                foreach (GameObject child in GameObject.FindGameObjectsWithTag("PlayerDeathShots"))
                {
                    if (IntersectCircleVSCircle(new SFCircle(position, hitboxLength), child.GetComponent<PlayerDeathShot>().GetHitBox()))
                    {
                        bonk = true;
                        break;
                    }
                }
                foreach (GameObject child in GameObject.FindGameObjectsWithTag("PlayerBomber"))
                {
                    if (IntersectCircleVSCircle(new SFCircle(position + new SFPoint(hitboxLength, (sfloat)0f), (sfloat)0.125f), child.GetComponent<Bomb>().GetHitBox())
                        || IntersectCircleVSCircle(new SFCircle(position + new SFPoint(hitboxLength * (sfloat)(-1f), (sfloat)0f), (sfloat)0.125f), child.GetComponent<Bomb>().GetHitBox()))
                    {
                        bonk = true;
                        break;
                    }
                }
                break;
        }
        if (bonk)
        {
            gManager.p1Score += 50;
            Cancel(false);
        }
    }

    public void Cancel(bool spawnItem)
    {
        gManager.p1Score += 10;
        gManager.rank += 10;
        if (col == BltColor.Yellow) gManager.medalDropCounter--;
        if (spawnItem)
        {
            GameObject gem = Instantiate(Resources.Load<GameObject>("Prefabs/Item"), transform.position, Quaternion.Euler(0, 0, 0));
            gem.GetComponent<ItemScript>().Setup(ItemScript.ItemType.Gem, position);
            Destroy(gameObject);
        }
        else
        {
            GameObject multifx = Instantiate(Resources.Load<GameObject>("Prefabs/FX"), transform.position, Quaternion.Euler(0, 0, 0));
            multifx.GetComponent<FXScript>().Setup((FXScript.BltColor)(int)col, position, velocity, shp == BltShape.LargeRugby);
            Destroy(gameObject);
        }
    }
}
