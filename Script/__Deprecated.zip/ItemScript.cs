using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using SoftFloat;
using SFAABBCC_Prereqs;
using static SFAABBCC_Prereqs.CC;

public class ItemScript : MonoBehaviour
{
    public enum ItemType
    {
        Gem = -4,
        Bomb,
        TwoUp,
        OneUp,
        Medal100,
        Medal200,
        Medal300,
        Medal400,
        Medal500,
        Medal600,
        Medal700,
        Medal800,
        Medal900,
        Medal1000,
        Medal2000,
        Medal3000,
        Medal4000,
        Medal5000,
        Medal6000,
        Medal7000,
        Medal8000,
        Medal9000,
        Medal10000
    }

    public ItemType type;
    public SFAABB itemBox;
    public SFPoint movement = new SFPoint((sfloat)0, (sfloat)0.1875f);

    sfloat maxSpeed;
    GameManager gManager;

    Sprite[] frames = new Sprite[4];
    int maxFrames;
    int frameCounter;
    SpriteRenderer rende;

    void Awake()
    {
        rende = GetComponent<SpriteRenderer>();
        gManager = FindObjectOfType<GameManager>();
    }

    public void Setup(ItemType m_type, SFPoint pos)
    {
        maxSpeed = ((sfloat) gManager.rank / (sfloat)1000000 * (sfloat)3 + (sfloat)3) / (sfloat)(-16);
        type = m_type;
        itemBox = new SFAABB(pos, new SFPoint((sfloat)2, (sfloat)2));
        transform.SetPositionAndRotation(new Vector3((float)itemBox.center.x, (float)itemBox.center.y, 0), transform.rotation);

        switch ((int)type)
        {
            case -4:
                frames[0] = gManager.itemAtlas.GetSprite("gem0_0");
                frames[1] = gManager.itemAtlas.GetSprite("gem0_1");
                frames[2] = gManager.itemAtlas.GetSprite("gem0_2");
                frames[3] = gManager.itemAtlas.GetSprite("gem0_3");
                maxFrames = 4;
                break;
            case -3:
                frames[0] = gManager.itemAtlas.GetSprite("bomb_0");
                frames[1] = gManager.itemAtlas.GetSprite("bomb_1");
                maxFrames = 2;
                break;
            case -2:
                frames[0] = gManager.itemAtlas.GetSprite("2up");
                maxFrames = 1;
                break;
            case -1:
                frames[0] = gManager.itemAtlas.GetSprite("1up");
                maxFrames = 1;
                break;
            case int n when n >= 0 && n < 19:
                frames[0] = gManager.itemAtlas.GetSprite("medal_" + n);
                maxFrames = 1;
                break;
        }
        rende.sprite = frames[0];
    }

    void FixedUpdate()
    {
        frameCounter++;
        frameCounter %= maxFrames * 4;
        rende.sprite = frames[frameCounter / 4];

        itemBox.center += movement;
        movement.y -= (sfloat)0.00625f;
        movement.y = Clamp(movement.y, (sfloat) 9, maxSpeed);
        if (sfloat.Abs(itemBox.center.y) > (sfloat)11 || sfloat.Abs(itemBox.center.x) > (sfloat)9)
        {
            if ((int)type >= 0) gManager.currentMedal = 0;
            Destroy(gameObject);
        }
        transform.SetPositionAndRotation(new Vector3((float)itemBox.center.x, (float)itemBox.center.y, 0), transform.rotation);
    }
}
