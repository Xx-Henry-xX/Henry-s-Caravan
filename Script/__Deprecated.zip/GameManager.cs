using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.U2D;

public class GameManager : MonoBehaviour
{
    public Text timer;
    public Text p1ScoreLarge;
    public Text p1ScoreSmall;
    public Text hiScoreLarge;
    public Text hiScoreSmall;
    public GameObject p1LastLifeText;
    public GameObject p1LivesHUD;
    public GameObject p1BombsHUD;
    public GameObject player;
    public SpriteAtlas bulletAtlas;
    public SpriteAtlas playerAtlas;
    public SpriteAtlas itemAtlas;
    public SpriteAtlas fxAtlas;

    public int p1Score = 0;
    public int p1Lives = 2;
    public int p1Bombs = 3;
    public int framesLeft = 7200;
    public int hiScore = 5000000;
    
    public int rank = 200000;
    public int rankPerFrame = 17;

    public readonly int[] medalScore = { 100, 200, 300, 400, 500, 600, 700, 800, 900, 1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000, 9000, 10000 };
    public readonly int[] medalRank = { 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 150, 200, 250, 300, 350, 400, 450, 500, 1000 };
    public int currentMedal = 0;
    public int medalDropCounter = 100;
    public int waitingExtends = 0; 

    // Start is called before the first frame update
    void Start()
    {
        rankPerFrame = 17 + p1Lives * 2 + p1Bombs * 3;
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        //TODO: fill this place w/ various stuffs
        if (framesLeft <= 0)
        {
            //Time Up script
        }
        else 
        {
            framesLeft--;
            rankPerFrame = 17 + p1Lives * 2 + p1Bombs * 3;
            rank += rankPerFrame;
            if (framesLeft % 10 == 0)
            {
                GameObject nmeToSpawn = (GameObject)Resources.Load("Prefabs/TestEnemy", typeof(GameObject));
                Instantiate(nmeToSpawn, new Vector3(15.0f, 15.0f, 0), transform.rotation);
            }
        }
        timer.text = (framesLeft / 3600).ToString() + ";" + (framesLeft % 3600 / 60).ToString("D2") + "," + (framesLeft % 60 / 6).ToString();
        p1BombsHUD.GetComponent<SpriteRenderer>().size = new Vector2(p1Bombs / 2.0f, 1);
        p1LivesHUD.GetComponent<SpriteRenderer>().size = new Vector2(p1Lives / 2.0f, 1);
        if (p1Lives == 0)
        {
            p1LastLifeText.SetActive(true);
        }
        else
        {
            p1LastLifeText.SetActive(false);
        }

        if (p1Score < 1000000)
        {
            p1ScoreLarge.text = "";
            p1ScoreSmall.text = (p1Score % 1000000).ToString();
        }
        else
        {
            p1ScoreLarge.text = (p1Score / 1000000).ToString();
            p1ScoreSmall.text = (p1Score % 1000000).ToString("D6");
        }
        if (hiScore < 1000000)
        {
            hiScoreLarge.text = "";
            hiScoreSmall.text = (hiScore % 1000000).ToString();
        }
        else
        {
            hiScoreLarge.text = (hiScore / 1000000).ToString();
            hiScoreSmall.text = (hiScore % 1000000).ToString("D6");
        }
    }
}
