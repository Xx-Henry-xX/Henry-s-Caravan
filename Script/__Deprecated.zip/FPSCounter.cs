using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class FPSCounter : MonoBehaviour
{
    Text tex;

    void Awake()
    {
        tex = GetComponent<Text>();
    }

    // Update is called once per frame
    void Update()
    {
        tex.text = ((int) (100f / Time.deltaTime)).ToString();
    }
}
