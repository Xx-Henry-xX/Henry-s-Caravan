using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using SoftFloat;
using SFAABBCC_Prereqs;

public class PlayerDeathShot : MonoBehaviour
{
    public sfloat speed = (sfloat)1;
    public int damage = 5;
    private SFPoint movement = SFPoint.ZeroSFPoint;
    private SFCircle shotBox;
    private SpriteRenderer shotRenderer;
    private Sprite[] frames = new Sprite[4];
    private int frameCounter = 0;
    void Awake()
    {
        shotRenderer = GetComponent<SpriteRenderer>();
        frames[0] = FindObjectOfType<GameManager>().bulletAtlas.GetSprite("Explosion1");
        frames[1] = FindObjectOfType<GameManager>().bulletAtlas.GetSprite("Explosion2");
        frames[2] = FindObjectOfType<GameManager>().bulletAtlas.GetSprite("Explosion3");
        frames[3] = FindObjectOfType<GameManager>().bulletAtlas.GetSprite("Explosion4");
        shotRenderer.sprite = frames[0];
    }

    public void Setup(sfloat speed, sfloat dir, SFPoint startPos)
    {
        shotBox = new SFCircle(startPos, (sfloat)0.75f);
        movement.x = speed * libm.sinf(dir / (sfloat)180 * sfloat.FromRaw(0x40490fdb));
        movement.y = speed * libm.cosf(dir / (sfloat)180 * sfloat.FromRaw(0x40490fdb));
        transform.SetPositionAndRotation(new Vector3((float)shotBox.center.x, (float)shotBox.center.y, 0), transform.rotation);
    }

    void FixedUpdate()
    {
        shotBox.center += movement;
        if (sfloat.Abs(shotBox.center.y) > (sfloat)11 || sfloat.Abs(shotBox.center.x) > (sfloat)9)
        {
            Destroy(gameObject);
        }
        transform.SetPositionAndRotation(new Vector3((float)shotBox.center.x, (float)shotBox.center.y, 0), transform.rotation);

        shotRenderer.sprite = frames[frameCounter / 2];
        frameCounter++;
        frameCounter %= 8;
    }

    public SFCircle GetHitBox()
    {
        return shotBox;
    }
}
