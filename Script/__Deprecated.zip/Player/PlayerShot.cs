using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using SoftFloat;
using SFAABBCC_Prereqs;

public class PlayerShot : MonoBehaviour
{
    public int damage = 3;
    public enum Direction
    {
        Left = -1,
        Center,
        Right
    }

    private Direction shotDirection = 0;
    private sfloat speed = (sfloat)1;
    private int shotID = 0;
    private SFPoint movement = SFPoint.ZeroSFPoint;
    private SFAABB shotBox;
    private SpriteRenderer shotRenderer;

    void Awake()
    {
        shotRenderer = GetComponent<SpriteRenderer>();
    }

    // Start is called before the first frame update
    public void Setup(int m_id, Direction m_dir, SFPoint startPos)
    {
        shotID = m_id;
        shotDirection = m_dir;
        shotBox = new SFAABB(startPos, new SFPoint((sfloat)0.5f, (sfloat)0.5625f));
        switch (shotDirection)
        {
            case Direction.Center:
                movement.x = (sfloat)0;
                movement.y = speed;
                shotRenderer.sprite = FindObjectOfType<GameManager>().playerAtlas.GetSprite("playershots_C");
                break;
            case Direction.Left:
                movement.x = speed * libm.sinf((sfloat)0.05f * sfloat.FromRaw(0x40490fdb)) * (sfloat)(-1); //no degToRad() or pi()? really??????
                movement.y = speed * libm.cosf((sfloat)0.05f * sfloat.FromRaw(0x40490fdb));
                shotRenderer.sprite = FindObjectOfType<GameManager>().playerAtlas.GetSprite("playershots_L");
                break;
            case Direction.Right:
                movement.x = speed * libm.sinf((sfloat)0.05f * sfloat.FromRaw(0x40490fdb));
                movement.y = speed * libm.cosf((sfloat)0.05f * sfloat.FromRaw(0x40490fdb));
                shotRenderer.sprite = FindObjectOfType<GameManager>().playerAtlas.GetSprite("playershots_R");
                break;
        }
        transform.SetPositionAndRotation(new Vector3((float)(shotBox.center.x), (float)shotBox.center.y, 0), transform.rotation);
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        shotBox.center += movement;
        if (sfloat.Abs(shotBox.center.y) > (sfloat)11 || sfloat.Abs(shotBox.center.x) > (sfloat)9)
        {
            Destroy(gameObject);
        }
        transform.SetPositionAndRotation(new Vector3((float)shotBox.center.x, (float)shotBox.center.y, 0), transform.rotation);
    }

    private void OnDestroy()
    {
        if (shotID != -1) GameObject.FindObjectOfType<GameManager>().player.GetComponent<PlayerController>().ReduceCount(shotID);
    }

    public SFAABB GetHitBox()
    {
        return shotBox;
    }
}
