using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using SoftFloat;
using SFAABBCC_Prereqs;
using static SFAABBCC_Prereqs.CC;

public class PlayerController : MonoBehaviour
{
    [Tooltip("Player speed when unfocused (1u = 16px)")]
    public float m_speed = 0.375f;
    [Tooltip("Player speed when focused (1u = 16px)")]
    public float m_focusSpeed = 0.1875f;
    [Tooltip("Analog Stick Sensitivity")]
    [Range(0.1f, 1.0f)]
    public float sensitivity = 0.5f;
    [Tooltip("1 shot every (n+1) frames")]
    public int firerate = 1;
    [Tooltip("GameObject to use as Shot")]
    public GameObject shotObject;
    [Tooltip("GameObject to use as DeathShot")]
    public GameObject deathShotObject;
    [Tooltip("GameObject to use as Bomber")]
    public GameObject bomberObject;

    public sfloat speed = (sfloat) 0.375f;
    public sfloat focusSpeed = (sfloat) 0.1875f;
    public SFPoint startPos = new SFPoint((sfloat)0, (sfloat)(-5));

    private SFPoint direction = SFPoint.ZeroSFPoint;
    private int tiltValue = 0;
    private Sprite[] sprites;

    private float horMov = 0;
    private float verMov = 0;
    private bool shotDown = false;
    private bool focusDown = false;
    private bool bombDown = false;

    private int[] shotCount = { 0, 0, 0, 0 };
    private int shotDelay = 0;
    private bool bombActive = false;

    private int ang = 0;
    private int iframe = 0;

    private SFAABB playerBox;
    private sfloat boxOffset;
    private SpriteRenderer rende;
    private GameManager gManager;

    // Start is called before the first frame update
    void Awake()
    {
        rende = GetComponent<SpriteRenderer>();
        gManager = FindObjectOfType<GameManager>();
        playerBox = new SFAABB(startPos, new SFPoint((sfloat)0.125f, (sfloat)0.125f));
        boxOffset = (sfloat) 0;
        speed = (sfloat)m_speed;
        focusSpeed = (sfloat)m_focusSpeed;
        transform.SetPositionAndRotation(new Vector3((float)(playerBox.center.x), (float)playerBox.center.y, 0), transform.rotation);
    }

    // Update is called once per frame
    void Update()
    {
        if (true) //replay mode check goes here
        {
            horMov = Mathf.Abs(Input.GetAxisRaw("Horizontal")) >= sensitivity ? Mathf.Sign(Input.GetAxisRaw("Horizontal")) : 0;
            verMov = Mathf.Abs(Input.GetAxisRaw("Vertical")) >= sensitivity ? Mathf.Sign(Input.GetAxisRaw("Vertical")) : 0;
            shotDown = false;
            if (Input.GetButton("Shot")) shotDown = true;
            focusDown = false;
            if (Input.GetButton("Focus")) focusDown = true;
            bombDown = false;
            if (Input.GetButton("Bomb")) bombDown = true;
        }
    }
    void FixedUpdate()
    {
        if (true)  //replay mode check goes here
        {
            //replay recording script goes here
            //up = 1
            //down = 2
            //left = 4
            //right = 8
            //shot = 16
            //focus = 32
            //bomb = 64
            //add all pressed buttons up and record it as single frame
        }
        else
        {
            //replay playback script goes here
        }

        direction = new SFPoint((sfloat)horMov, (sfloat)verMov);
        direction.normalize();
        if (focusDown)
        {
            direction *= focusSpeed;
        }
        else
        {
            direction *= speed;
        }

        switch (ang)
        {
            case 0:
                Movement(false);
                ItemCheck();
                Shoot();

                bool bonk = false;
                foreach (GameObject blt in GameObject.FindGameObjectsWithTag("Bullets"))
                {
                    switch (blt.GetComponent<Bullet>().hitboxType)
                    {
                        case Bullet.HitBoxType.Circle:
                            if (IntersectCircleVSBox(new SFCircle(blt.GetComponent<Bullet>().position, blt.GetComponent<Bullet>().hitboxLength), GetHitBox()))
                            {
                                bonk = true;
                                blt.GetComponent<Bullet>().Cancel(false);
                            }
                            break;
                        case Bullet.HitBoxType.Line:
                            SFPoint dir = blt.GetComponent<Bullet>().velocity;
                            dir.normalize();
                            dir *= blt.GetComponent<Bullet>().hitboxLength;
                            if (IntersectBoxVSSegment(GetHitBox(), blt.GetComponent<Bullet>().position, dir))
                            {
                                bonk = true;
                                blt.GetComponent<Bullet>().Cancel(false);
                            }
                            break;
                        case Bullet.HitBoxType.Pulse:
                            if (IntersectCircleVSBox(new SFCircle(blt.GetComponent<Bullet>().position + new SFPoint(blt.GetComponent<Bullet>().hitboxLength, (sfloat)0f), (sfloat)0.125f), GetHitBox())
                                || IntersectCircleVSBox(new SFCircle(blt.GetComponent<Bullet>().position + new SFPoint(blt.GetComponent<Bullet>().hitboxLength * (sfloat)(-1f), (sfloat)0f), (sfloat)0.125f), GetHitBox()))
                            {
                                bonk = true;
                                blt.GetComponent<Bullet>().Cancel(false);
                            }
                            break;
                    }
                }

                if (bonk && iframe == 0)
                {
                    GameObject fx = Instantiate(Resources.Load<GameObject>("Prefabs/FX"), transform.position, Quaternion.Euler(0, 0, 0));
                    fx.GetComponent<FXScript>().Setup(3, 0);
                    for (sfloat i = (sfloat)0; i < (sfloat)360; i += (sfloat)20)
                    {
                        GameObject ds = Instantiate(deathShotObject, new Vector3((float)(playerBox.center.x), (float)playerBox.center.y, 0), Quaternion.Euler(0, 0, 0));
                        ds.GetComponent<PlayerDeathShot>().Setup((sfloat)0.25f, i, playerBox.center);
                    }
                    for (sfloat i = (sfloat)10; i < (sfloat)360; i += (sfloat)20)
                    {
                        GameObject ds = Instantiate(deathShotObject, new Vector3((float)(playerBox.center.x), (float)playerBox.center.y, 0), Quaternion.Euler(0, 0, 0));
                        ds.GetComponent<PlayerDeathShot>().Setup((sfloat)0.28125f, i, playerBox.center);
                    }
                    for (sfloat i = (sfloat)0; i < (sfloat)360; i += (sfloat)20)
                    {
                        GameObject ds = Instantiate(deathShotObject, new Vector3((float)(playerBox.center.x), (float)playerBox.center.y, 0), Quaternion.Euler(0, 0, 0));
                        ds.GetComponent<PlayerDeathShot>().Setup((sfloat)0.3125f, i, playerBox.center);
                    }
                    for (sfloat i = (sfloat)10; i < (sfloat)360; i += (sfloat)20)
                    {
                        GameObject ds = Instantiate(deathShotObject, new Vector3((float)(playerBox.center.x), (float)playerBox.center.y, 0), Quaternion.Euler(0, 0, 0));
                        ds.GetComponent<PlayerDeathShot>().Setup((sfloat)0.34375f, i, playerBox.center);
                    }
                    for (sfloat i = (sfloat)0; i < (sfloat)360; i += (sfloat)20)
                    {
                        GameObject ds = Instantiate(deathShotObject, new Vector3((float)(playerBox.center.x), (float)playerBox.center.y, 0), Quaternion.Euler(0, 0, 0));
                        ds.GetComponent<PlayerDeathShot>().Setup((sfloat)0.375f, i, playerBox.center);
                    }
                    ang = 3;
                    rende.color = Color.clear;
                }

                if (iframe > 0)
                {
                    iframe--;
                    rende.color = new Color(1, 1, 1, rende.color.a == 1 ? 0 : 1);
                } 
                else rende.color = new Color(1, 1, 1, 1);

                break;

            case 1:
                direction.x = direction.x == (sfloat)0 ? (sfloat)0 : libm.sqrtf(focusDown ? focusSpeed * focusSpeed - (sfloat) 0.01f : speed * speed - (sfloat) 0.01f) * (sfloat) direction.x.Sign();
                direction.y = (sfloat) 0.1f;
                Movement(true);
                ItemCheck();
                Shoot();
                iframe++;
                rende.color = new Color(1, 1, 1, rende.color.a == 1 ? 0 : 1);

                foreach (GameObject blt in GameObject.FindGameObjectsWithTag("Bullets"))
                {
                    switch (blt.GetComponent<Bullet>().hitboxType)
                    {
                        case Bullet.HitBoxType.Circle:
                            if (IntersectCircleVSBox(new SFCircle(blt.GetComponent<Bullet>().position, blt.GetComponent<Bullet>().hitboxLength), GetHitBox()))
                            {
                                blt.GetComponent<Bullet>().Cancel(false);
                            }
                            break;
                        case Bullet.HitBoxType.Line:
                            SFPoint dir = blt.GetComponent<Bullet>().velocity;
                            dir.normalize();
                            dir *= blt.GetComponent<Bullet>().hitboxLength;
                            if (IntersectBoxVSSegment(GetHitBox(), blt.GetComponent<Bullet>().position, dir))
                            {
                                blt.GetComponent<Bullet>().Cancel(false);
                            }
                            break;
                        case Bullet.HitBoxType.Pulse:
                            if (IntersectCircleVSBox(new SFCircle(blt.GetComponent<Bullet>().position + new SFPoint(blt.GetComponent<Bullet>().hitboxLength, (sfloat)0f), (sfloat)0.125f), GetHitBox())
                                || IntersectCircleVSBox(new SFCircle(blt.GetComponent<Bullet>().position + new SFPoint(blt.GetComponent<Bullet>().hitboxLength * (sfloat)(-1f), (sfloat)0f), (sfloat)0.125f), GetHitBox()))
                            {
                                blt.GetComponent<Bullet>().Cancel(false);
                            }
                            break;
                    }
                }

                if (playerBox.center.y >= startPos.y - (sfloat) 0.1f)
                {
                    ang = 0;
                    iframe = 120;
                }
                break;

            case 2:
                playerBox.center.y = (sfloat)(-256);
                if (GameObject.FindGameObjectsWithTag("PlayerDeathShots").Length == 0)
                {
                    if (gManager.p1Lives == 0)
                    {
                        //game over goes here
                    }
                    else
                    {
                        ang = 1;
                        gManager.p1Lives--;
                        gManager.p1Bombs += 3;
                        gManager.p1Bombs = Mathf.Clamp(gManager.p1Bombs, 0, 5);
                        playerBox.center.y = (sfloat)(-11);
                    }
                }
                break;

            case 3:
                rende.color = Color.clear;
                ang = 2;
                tiltValue = 0;
                break;
        }
    }

    public SFAABB GetHitBox()
    {
        return new SFAABB(new SFPoint(playerBox.center.x + boxOffset, playerBox.center.y), playerBox.halfLength);
    }

    public void ReduceCount(int i)
    {
        if (i >= 0 && i < 4)
        {
            shotCount[i]--;
            if (shotCount[i] < 0)
            {
                shotCount[i] = 0;
            }
        }
    }

    public bool GetBombHeld()
    {
        return bombDown;
    }

    public void EndBomb()
    {
        bombActive = false;
    }

    public bool GetFreeX10()
    {
        if (ang == 0 && iframe <= 0) return false;
        return true;
    }

    private void Movement(bool ignoreY)
    {
        playerBox.center += direction;
        if (sfloat.Abs(playerBox.center.x) > (sfloat)7)
        {
            playerBox.center.x = (sfloat)(playerBox.center.x.Sign() * 7);
        }
        if (!ignoreY && playerBox.center.y > (sfloat)7)
        {
            playerBox.center.y = (sfloat)7;
        }
        if (!ignoreY && playerBox.center.y < (sfloat)(-8.5) && ang == 0)
        {
            playerBox.center.y = (sfloat)(-8.5);
        }

        if (horMov == 0)
        {
            tiltValue += Math.Sign(tiltValue) * -1;
        }
        else
        {
            tiltValue += (int) Mathf.Sign(horMov);
        }
        tiltValue = Mathf.Clamp(tiltValue, -12, 12);
        switch (tiltValue)
        {
            case int n when (n <= -8):
                playerBox.halfLength = new SFPoint((sfloat)0.125f, (sfloat)0.1875f);
                boxOffset = (sfloat)(-0.0625f);
                rende.sprite = gManager.playerAtlas.GetSprite("player_0");
                break;
            case int n when (n <= -3 && n > -8):
                playerBox.halfLength = new SFPoint((sfloat)0.15625f, (sfloat)0.1875f);
                boxOffset = (sfloat)(-0.03125f);
                rende.sprite = gManager.playerAtlas.GetSprite("player_1");
                break;
            case int n when (n >= 8):
                playerBox.halfLength = new SFPoint((sfloat)0.125f, (sfloat)0.1875f);
                boxOffset = (sfloat)(0.0625f);
                rende.sprite = gManager.playerAtlas.GetSprite("player_4");
                break;
            case int n when (n >= 3 && n < 8):
                playerBox.halfLength = new SFPoint((sfloat)0.15625f, (sfloat)0.1875f);
                boxOffset = (sfloat)(0.03125f);
                rende.sprite = gManager.playerAtlas.GetSprite("player_3");
                break;
            default:
                playerBox.halfLength = new SFPoint((sfloat)0.1875f, (sfloat)0.1875f);
                boxOffset = (sfloat)(0);
                rende.sprite = gManager.playerAtlas.GetSprite("player_2");
                break;
        }
        transform.SetPositionAndRotation(new Vector3((float)(playerBox.center.x), (float)playerBox.center.y, 0), transform.rotation);
    }

    private void Shoot()
    {
        if (shotDelay <= 0 && shotDown)
        {
            shotDelay = firerate;
            for (int i = 0; i < 4; i++)
            {
                if (shotCount[i] < 4)
                {
                    GameObject shot = Instantiate(shotObject, new Vector3((float)(playerBox.center.x), (float)playerBox.center.y, 0), transform.rotation);
                    shotCount[i]++;
                    switch (i)
                    {
                        case 0:
                            shot.GetComponent<PlayerShot>().Setup(i, PlayerShot.Direction.Left, new SFPoint(playerBox.center.x - (sfloat)0.375, playerBox.center.y));
                            break;
                        case 1:
                            shot.GetComponent<PlayerShot>().Setup(i, PlayerShot.Direction.Center, new SFPoint(playerBox.center.x - (sfloat)0.375, playerBox.center.y));
                            break;
                        case 2:
                            shot.GetComponent<PlayerShot>().Setup(i, PlayerShot.Direction.Center, new SFPoint(playerBox.center.x + (sfloat)0.375, playerBox.center.y));
                            break;
                        case 3:
                            shot.GetComponent<PlayerShot>().Setup(i, PlayerShot.Direction.Right, new SFPoint(playerBox.center.x + (sfloat)0.375, playerBox.center.y));
                            break;
                    }
                }
            }
        }
        else shotDelay--;

        if (bombDown && !bombActive && gManager.p1Bombs > 0)
        {
            GameObject bomb = Instantiate(bomberObject, new Vector3((float)playerBox.center.x, (float)playerBox.center.y, 0), transform.rotation);
            bomb.GetComponent<Bomb>().Setup(playerBox.center);
            bombActive = true;
            gManager.p1Bombs--;
            foreach (GameObject blt in GameObject.FindGameObjectsWithTag("Bullets")) blt.GetComponent<Bullet>().Cancel(true);
        }

        if (bombActive) iframe = 60;
    }

    private void ItemCheck()
    {
        foreach (GameObject item in GameObject.FindGameObjectsWithTag("Items"))
        {
            if (IntersectBoxVSBox(GetHitBox(), item.GetComponent<ItemScript>().itemBox))
            {
                switch ((int)item.GetComponent<ItemScript>().type)
                {
                    case -4:
                        gManager.p1Score += 100;
                        gManager.rank += 10;
                        GameObject sc = Instantiate(Resources.Load<GameObject>("Prefabs/FX"), item.transform.position, item.transform.rotation);
                        sc.GetComponent<FXScript>().Setup(1, 100);
                        break;
                    case -3:
                        gManager.p1Bombs++;
                        if (gManager.p1Bombs > 5)
                        {
                            gManager.p1Bombs--;
                            GameObject fiveKilo = Instantiate(Resources.Load<GameObject>("Prefabs/FX"), item.transform.position, item.transform.rotation);
                            fiveKilo.GetComponent<FXScript>().Setup(1, 5000);
                        }
                        gManager.rank += 10; //TODO: adjust
                        break;
                    case -2:
                        gManager.p1Lives += 2;
                        gManager.rank += 10; //TODO: adjust
                        break;
                    case -1:
                        gManager.p1Lives++;
                        gManager.rank += 10; //TODO: adjust
                        break;
                    case int n when n >= 0 && n < 19:
                        GameObject multifx = Instantiate(Resources.Load<GameObject>("Prefabs/FX"), item.transform.position, item.transform.rotation);
                        multifx.GetComponent<FXScript>().Setup(1, gManager.medalScore[n]);
                        gManager.p1Score += gManager.medalScore[n];
                        gManager.rank += gManager.medalRank[n];
                        gManager.currentMedal = Mathf.Clamp(n + 1, 0, 18);
                        break;
                }
                Destroy(item);
            }
        }
    }
}