using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using SoftFloat;
using SFAABBCC_Prereqs;

public class Bomb : MonoBehaviour
{
    public sfloat speed = (sfloat)1;
    public int damage = 1;
    private SFCircle shotBox;
    private SpriteRenderer shotRenderer;
    private Sprite[] shellFrames = new Sprite[2];
    private Sprite[] bomberFrames = new Sprite[14];
    private int frameCounter = 0;
    private bool flying = true;
    private GameManager gManager;

    void Awake()
    {
        gManager = FindObjectOfType<GameManager>();
        shotRenderer = GetComponent<SpriteRenderer>();
        shellFrames[0] = gManager.playerAtlas.GetSprite("bomber_shell_0");
        shellFrames[1] = gManager.playerAtlas.GetSprite("bomber_shell_1");
        shotRenderer.sprite = shellFrames[0];
        for (int i = 0; i < 14; i++)
            bomberFrames[i] = gManager.playerAtlas.GetSprite("bomber_" + i);
    }

    public void Setup(SFPoint startPos)
    {
        shotBox = new SFCircle(startPos, (sfloat)2);
        transform.SetPositionAndRotation(new Vector3((float)(shotBox.center.x), (float)shotBox.center.y, 0), transform.rotation);
    }
    public SFCircle GetHitBox()
    {
        return shotBox;
    }

    void FixedUpdate()
    {
        if (flying)
        {
            shotBox.center.y += (sfloat)0.5f;
            transform.SetPositionAndRotation(new Vector3((float)(shotBox.center.x), (float)shotBox.center.y, 0), transform.rotation);

            frameCounter %= 4;
            shotRenderer.sprite = shellFrames[frameCounter/2];
            

            if (!gManager.player.GetComponent<PlayerController>().GetBombHeld() ||shotBox.center.y > (sfloat)6)
            {
                flying = false;
                frameCounter = 0;
                shotBox.radius = (sfloat)5;
                shotRenderer.sprite = bomberFrames[0];
            }
        }
        else
        {
            switch (frameCounter)
            {
                case int n when (n < 2):
                    shotRenderer.sprite = bomberFrames[0];
                    break;
                case int n when (n < 4):
                    shotRenderer.sprite = bomberFrames[1];
                    break;
                case int n when (n < 6):
                    shotRenderer.sprite = bomberFrames[2];
                    break;
                case int n when (n < 8):
                    shotRenderer.sprite = bomberFrames[3];
                    break;
                case int n when (n < 10):
                    shotRenderer.sprite = bomberFrames[4];
                    break;
                case int n when (n < 12):
                    shotRenderer.sprite = bomberFrames[5];
                    break;
                case int n when (n < 14):
                    shotRenderer.sprite = bomberFrames[6];
                    break;
                case int n when (n < 16):
                    shotRenderer.sprite = bomberFrames[7];
                    break;
                case int n when (n < 18):
                    shotRenderer.sprite = bomberFrames[8];
                    break;

                case int n when (n < 110):
                    Random.InitState(gManager.p1Score + gManager.rank + frameCounter);
                    SFPoint offset = SFPoint.ZeroSFPoint;
                    sfloat randius;
                    sfloat theta;
                    
                    randius = libm.sqrtf((sfloat)Random.Range(0, 36));
                    theta = (sfloat)Random.Range(0, int.MaxValue) / (sfloat)int.MaxValue * sfloat.FromRaw(0x40c90fdb);
                    offset.x = randius / (sfloat)16 * libm.sinf(theta);
                    offset.y = randius / (sfloat)16 * libm.cosf(theta);
                    transform.SetPositionAndRotation(new Vector3((float)(shotBox.center.x + offset.x), (float)(shotBox.center.y + offset.y), 0), transform.rotation);
                    
                    GameObject fx;

                    randius = libm.sqrtf((sfloat)Random.Range(0, 2500));
                    theta = (sfloat)Random.Range(0, int.MaxValue) / (sfloat)int.MaxValue * sfloat.FromRaw(0x40c90fdb);
                    offset.x = randius / (sfloat)16 * libm.sinf(theta);
                    offset.y = randius / (sfloat)16 * libm.cosf(theta);
                    fx = Instantiate(Resources.Load<GameObject>("Prefabs/FX"), transform.position, Quaternion.Euler(0, 0, 0));
                    fx.GetComponent<FXScript>().Setup((FXScript.BltColor)2, shotBox.center + offset, SFPoint.ZeroSFPoint, false);
                    fx.GetComponent<FXScript>().ThisIsABombFX();

                    SFPoint vel = SFPoint.ZeroSFPoint;

                    randius = libm.sqrtf((sfloat)Random.Range(11025, 14400));
                    theta = (sfloat)Random.Range(0, int.MaxValue) / (sfloat)int.MaxValue * sfloat.FromRaw(0x40c90fdb);
                    offset.x = randius / (sfloat)16 * libm.sinf(theta);
                    offset.y = randius / (sfloat)16 * libm.cosf(theta);
                    vel.x = libm.sinf(theta);
                    vel.y = libm.cosf(theta);
                    vel *= (sfloat)(-1);
                    fx = Instantiate(Resources.Load<GameObject>("Prefabs/FX"), transform.position, Quaternion.Euler(0, 0, 0));
                    fx.GetComponent<FXScript>().Setup(4, 0);
                    fx.GetComponent<FXScript>().ThisIsABombFX(offset + shotBox.center, vel);

                    break;

                case int n when (n < 112):
                    shotRenderer.sprite = bomberFrames[9];
                    transform.SetPositionAndRotation(new Vector3((float)(shotBox.center.x), (float)shotBox.center.y, 0), transform.rotation);
                    break;
                case int n when (n < 114):
                    shotRenderer.sprite = bomberFrames[10];
                    break;
                case int n when (n < 116):
                    shotRenderer.sprite = bomberFrames[11];
                    break;
                case int n when (n < 118):
                    shotRenderer.sprite = bomberFrames[12];
                    break;
                case int n when (n < 120):
                    shotRenderer.sprite = bomberFrames[13];
                    break;
                default:
                    Destroy(gameObject);
                    gManager.player.GetComponent<PlayerController>().EndBomb();
                    break;
            }
        }
        frameCounter++;
    }
}
