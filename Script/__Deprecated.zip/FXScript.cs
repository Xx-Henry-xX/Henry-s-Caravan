using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using SoftFloat;
using SFAABBCC_Prereqs;

public class FXScript : MonoBehaviour
{
    public int type; // 0 = multiplier, 1 = medal score, 2 = bullet cancel
    public int value;

    int counter = 0;
    SpriteRenderer rende;
    Sprite[] special = new Sprite[5];
    SFPoint pos;
    SFPoint vel;

    public enum BltColor
    {
        Yellow = 0,
        Blue,
        Red,
        Purple,
        Pink,
        Magenta
    }

    void Awake()
    {
        rende = GetComponent<SpriteRenderer>();
    }
    public void Setup(int m_type, int m_value)
    {
        type = m_type;
        value = m_value;

        switch (type)
        {
            case 0: //multiplier
                if (value == 10)
                {
                    special = new Sprite[2];
                    special[0] = FindObjectOfType<GameManager>().fxAtlas.GetSprite("x10");
                    special[1] = FindObjectOfType<GameManager>().fxAtlas.GetSprite("x10a");
                    rende.sprite = special[0];
                }
                else rende.sprite = FindObjectOfType<GameManager>().fxAtlas.GetSprite("x" + value);
                break;
            case 1: //score
                rende.sprite = FindObjectOfType<GameManager>().fxAtlas.GetSprite(value + "pt");
                break;
            case 3: //player death
                special = new Sprite[13];
                for (int i = 0; i < 13; i++)
                    special[i] = FindObjectOfType<GameManager>().fxAtlas.GetSprite("plydeth_" + i);
                rende.sortingLayerName = "Player";
                rende.sprite = special[0];
                break;
            case 4: //bomb zoom
                special = new Sprite[4];
                for (int i = 0; i < 4; i++)
                    special[i] = FindObjectOfType<GameManager>().fxAtlas.GetSprite("bomber_fx_" + i);
                rende.sortingLayerName = "Bomber";
                rende.sortingOrder = 2;
                rende.sprite = special[0];
                break;
            default:
                break;
        }
    }

    public void Setup(BltColor col, SFPoint m_pos, SFPoint m_vel, bool large)
    {
        type = 2;
        pos = m_pos;
        vel = m_vel;
        transform.SetPositionAndRotation(new Vector3((float)pos.x, (float)pos.y, 0), transform.rotation);

        float a = 0f;
        switch (col)
        {
            case BltColor.Yellow:
                a = -180f;
                break;
            case BltColor.Blue:
                a = 0f;
                break;
            case BltColor.Red:
                a = -240f;
                break; //240 0 270 300 330 --(subtract 240)-> 0 -240 30 60 90 
            case BltColor.Purple:
                a = 30f;
                break;
            case BltColor.Magenta:
                a = 60f;
                break;
            case BltColor.Pink:
                a = 90f;
                break;
        }
        rende.material.SetVector("_HSVAAdjust", new Vector4(a / 360f, 0, 0, 0));
        special[0] = FindObjectOfType<GameManager>().bulletAtlas.GetSprite((large ? "LargeExpl" : "Explosion") + "0");
        special[1] = FindObjectOfType<GameManager>().bulletAtlas.GetSprite((large ? "LargeExpl" : "Explosion") + "1");
        special[2] = FindObjectOfType<GameManager>().bulletAtlas.GetSprite((large ? "LargeExpl" : "Explosion") + "2");
        special[3] = FindObjectOfType<GameManager>().bulletAtlas.GetSprite((large ? "LargeExpl" : "Explosion") + "3");
        special[4] = FindObjectOfType<GameManager>().bulletAtlas.GetSprite((large ? "LargeExpl" : "Explosion") + "4");
        rende.sprite = special[0];
        counter = 2;
    }

    public void ThisIsABombFX()
    {
        rende.sortingLayerName = "Bomber";
        rende.sortingOrder = 2;
    }

    public void ThisIsABombFX(SFPoint m_pos, SFPoint m_vel)
    {
        pos = m_pos;
        vel = m_vel;
        transform.SetPositionAndRotation(new Vector3((float)pos.x, (float)pos.y, 0), transform.rotation);
    }

    public void Setup(BltColor col, SFPoint m_pos)
    {
        rende.sortingLayerName = "Exhaust";
        type = 2;
        pos = m_pos;
        vel = SFPoint.ZeroSFPoint;
        transform.SetPositionAndRotation(new Vector3((float)pos.x, (float)pos.y, 0), transform.rotation);

        float a = 0f;
        switch (col)
        {
            case BltColor.Yellow:
                a = -60f;
                break;
            case BltColor.Blue:
                a = 0f;
                break;
            case BltColor.Red:
                a = -240f;
                break;
            case BltColor.Purple:
                a = 30f;
                break;
            case BltColor.Magenta:
                a = 60f;
                break;
            case BltColor.Pink:
                a = 90f;
                break;
        }
        rende.material.SetVector("_HSVAAdjust", new Vector4(a / 360f, 0, 0, 0));
        special[0] = FindObjectOfType<GameManager>().bulletAtlas.GetSprite("Exhaust_0");
        special[1] = FindObjectOfType<GameManager>().bulletAtlas.GetSprite("Exhaust_1");
        special[2] = FindObjectOfType<GameManager>().bulletAtlas.GetSprite("Exhaust_2");
        special[3] = FindObjectOfType<GameManager>().bulletAtlas.GetSprite("Exhaust_3");
        special[4] = FindObjectOfType<GameManager>().bulletAtlas.GetSprite("Exhaust_4");
        rende.sprite = special[0];
        counter = 2;
    }

    void FixedUpdate()
    {
        if (type == 0)
        {
            switch (counter)
            {
                case int n when (n < 5):
                    transform.localScale = new Vector3(n / 5f , 2f - (n/5f), 1);
                    break;
                case int n when (n > 54):
                    transform.localScale = new Vector3(1f + ((n-54)/10f), (60 - n) / 5f, 1);
                    break;
                default:
                    transform.localScale = new Vector3(1, 1, 1);
                    break;
            }
            if (value == 10)
            {
                rende.sprite = special[counter % 2];
            }
        }
        if (type == 2)
        {
            pos += vel;
            transform.SetPositionAndRotation(new Vector3((float)pos.x, (float)pos.y, 0), transform.rotation);
            rende.sprite = special[counter / 3];
        }
        if (type == 3)
        {
            rende.sprite = special[counter / 2];
        }
        if (type == 4)
        {
            sfloat spd = (sfloat)(14 - counter);
            switch (counter)
            {
                case int n when (n < 2):
                    rende.sprite = special[0];
                    break;
                case int n when (n < 5):
                    rende.sprite = special[1];
                    break;
                case int n when (n < 9):
                    rende.sprite = special[2];
                    break;
                default:
                    rende.sprite = special[3];
                    break;
            }
            pos += vel * (spd / (sfloat) 16);
            transform.SetPositionAndRotation(new Vector3((float)pos.x, (float)pos.y, 0), transform.rotation);
        }
        counter++;
        if ((counter >= 60 && type < 2)||(counter >= 15 && type == 2)||(counter >= 26 && type == 3)||(counter >= 15 && type == 4)) Destroy(gameObject);
    }
}
